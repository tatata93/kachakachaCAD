"""Evidence-bound intermediate geometry trials; never labels a preview as final."""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,time

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path,data):path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8',newline='\n')


def run(command,folder,name,env=None):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.perf_counter()
    print(name,flush=True)
    with (folder/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([str(c) for c in command],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env)
    record=dict(command=[str(c) for c in command],startUtc=start,
        endUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.perf_counter()-tic,exit=result.returncode)
    write(folder/(name+'.json'),record)
    if result.returncode:raise RuntimeError(f'{name}: exit {result.returncode}; see {folder/(name+".log")}')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('stage',type=int);ap.add_argument('work',type=Path)
    ap.add_argument('--exe',type=Path,required=True);ap.add_argument('--exporter',type=Path,required=True)
    ap.add_argument('--bogie',type=Path,required=True);ap.add_argument('--baseline',type=Path,required=True)
    ap.add_argument('--reuse-native',type=Path,help='Reuse only exact model/exe matching native proof, never a commit-name match')
    a=ap.parse_args();folder=a.work.resolve();folder.mkdir(parents=True,exist_ok=False)
    files=sorted(p for p in (ROOT/'tools/modeling').rglob('*') if p.suffix in ['.py','.cpp','.h','.txt'] and '__pycache__' not in p.parts)
    sources={str(p.relative_to(ROOT)).replace('\\','/'):sha(p) for p in files}
    for p in files:
        destination=folder/'sources'/p.relative_to(ROOT);destination.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,destination)
    write(folder/'source-provenance.json',dict(stage=a.stage,timeUtc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        sourceFiles=sources,exeSha256=sha(a.exe),exporterSha256=sha(a.exporter),bogieSha256=sha(a.bogie)))
    model=folder/'candidate/kuha115-ho80-revised.kcd2';design=folder/'candidate/design.json';exports=folder/'exports'
    py=sys.executable
    run([py,HERE/'revised.py','--detailed','--contoured','--appearance-pass','5','--refinement-pass',a.stage,
        '--bogie-component',a.bogie,'--output',model.parent],folder,'01-generate')
    if a.reuse_native:
        original=a.reuse_native.resolve();validation=original/'validation.json';proof=json.loads(validation.read_text(encoding='utf-8'))
        assert proof['passed'] and proof['unchanged'] and proof['modelSha']==sha(model) and proof['exeSha']==sha(a.exe)
        native=folder/'native';native.mkdir()
        for name in ['validation.json','prepared.bin']:shutil.copy2(original/name,native/name)
        write(folder/'02-native-reused.json',dict(original=str(original),validationSha256=sha(validation),
            preparedSha256=sha(original/'prepared.bin'),modelSha256=sha(model),exeSha256=sha(a.exe),token=proof['token']))
    else:run([py,ROOT/'tools/modeling/series115_print/validate_model.py',model,a.exe,'--work',folder/'native'],folder,'02-native')
    env=os.environ.copy();env['PATH']=str(a.exe.parent)+os.pathsep+env.get('PATH','')
    run([a.exporter,folder/'native/prepared.bin',design,exports,'--preview-only'],folder,'03-export',env)
    run([py,ROOT/'tools/modeling/series115_print/check_stl.py',exports],folder,'04-stl')
    run([py,HERE/'inspect_refinement.py',exports,folder/'inspection.json','--baseline',a.baseline],folder,'05-seam')
    run([py,HERE/'render_detailed.py',exports,design,folder/'previews','--diagnostic-front'],folder,'06-render')
    for name,digest in sources.items():assert sha(ROOT/name)==digest,f'Source changed during candidate: {name}'
    proof={str(p.relative_to(folder)).replace('\\','/'):sha(p) for p in [model,design,folder/'native/validation.json',
        exports/'print-parts.json',exports/'stl-validation.json',folder/'inspection.json',folder/'previews/render-proof.json']}
    write(folder/'result.json',dict(stage=a.stage,geometryPassed=True,visualReview='pending',finalPrintRelease=False,
        modelSha256=sha(model),evidence=proof,endUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    print('GEOMETRY PASSED; image review pending',flush=True)


if __name__=='__main__':main()

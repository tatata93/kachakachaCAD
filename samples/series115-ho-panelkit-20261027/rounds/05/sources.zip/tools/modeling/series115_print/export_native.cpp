#include <QCoreApplication>
#include <QDataStream>
#include <QFile>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QString>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass3d_SolidClassifier.hxx>
#include <BRepGProp.hxx>
#include <BRepAlgoAPI_Common.hxx>
#include <BRepAlgoAPI_Cut.hxx>
#include <BRepAlgoAPI_Fuse.hxx>
#include <BRepExtrema_DistShapeShape.hxx>
#include <BRepBuilderAPI_Transform.hxx>
#include <BRepBuilderAPI_MakeVertex.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <IntCurvesFace_ShapeIntersector.hxx>
#include <TopoDS.hxx>
#include <BRepPrimAPI_MakeBox.hxx>
#include <TopoDS_Compound.hxx>
#include <TopTools_ListOfShape.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <GProp_GProps.hxx>
#include <Bnd_Box.hxx>
#include <BRepBndLib.hxx>
#include <TopoDS_Shape.hxx>
#include <TopExp_Explorer.hxx>
#include <STEPControl_Writer.hxx>
#include <STEPControl_Reader.hxx>
#include <StlAPI_Writer.hxx>
#include <Interface_Static.hxx>
#include <sstream>
#include <iostream>
#include <map>
#include <set>
#include <stdexcept>
#include <cmath>
#include <memory>

std::string Text(QDataStream& s) {
    quint64 n;s>>n;if(n>512*1024*1024)throw std::runtime_error("oversized field");
    std::string result(n,'\0');if(s.readRawData(result.data(),int(n))!=qint64(n))throw std::runtime_error("short field");return result;
}
QJsonObject Json(const QString& p){QFile f(p);if(!f.open(QIODevice::ReadOnly))throw std::runtime_error("missing JSON");return QJsonDocument::fromJson(f.readAll()).object();}

TopoDS_Shape ReadShape(const std::map<std::string,std::string>& shapes,const QString& id) {
    const auto found=shapes.find(id.toStdString());
    if(found==shapes.end())throw std::runtime_error("missing CAD-evaluated shape");
    std::istringstream stream(found->second);BRep_Builder builder;TopoDS_Shape shape;
    BRepTools::Read(shape,stream,builder);return shape;
}

double Volume(const TopoDS_Shape& shape) {
    GProp_GProps prop;if(!shape.IsNull())BRepGProp::VolumeProperties(shape,prop,1e-10);
    return std::abs(prop.Mass());
}

TopoDS_Shape ContactIntersection(const TopoDS_Shape& a,const TopoDS_Shape& b){
    BRepAlgoAPI_Common operation;TopTools_ListOfShape args,tools;args.Append(a);tools.Append(b);
    operation.SetArguments(args);operation.SetTools(tools);operation.SetNonDestructive(true);operation.Build();
    if(!operation.IsDone())throw std::runtime_error("contact intersection failed");return operation.Shape();
}
TopoDS_Shape ContactShape(const QJsonObject& check,const QString& key,const std::map<std::string,std::string>& shapes){
    if(!check.contains(key+"Parts"))return ReadShape(shapes,check[key].toString());
    const auto ids=check[key+"Parts"].toArray();if(ids.isEmpty())throw std::runtime_error("empty contact assembly");
    TopoDS_Shape result;std::set<QString> unique;
    for(const auto id:ids){if(!unique.insert(id.toString()).second)throw std::runtime_error("duplicate contact part");
        const auto part=ReadShape(shapes,id.toString());if(result.IsNull())result=part;
        else {BRepAlgoAPI_Fuse join(result,part);join.Build();if(!join.IsDone())throw std::runtime_error("contact assembly failed");
            join.SimplifyResult();result=join.Shape();}}
    return result;
}
struct ContactFace {TopoDS_Shape shape;double b[6];};
std::vector<ContactFace> ContactFaces(const TopoDS_Shape& shape){
    std::vector<ContactFace> faces;
    for(TopExp_Explorer ex(shape,TopAbs_FACE);ex.More();ex.Next()){
        ContactFace face;face.shape=ex.Current();Bnd_Box box;BRepBndLib::AddOptimal(face.shape,box,false,false);
        if(box.IsVoid())continue;box.Get(face.b[0],face.b[1],face.b[2],face.b[3],face.b[4],face.b[5]);faces.push_back(face);}
    return faces;
}
QJsonArray CheckContacts(const QJsonObject& design,const std::map<std::string,std::string>& shapes,int& failures){
    QJsonArray results;
    for(const auto value:design["attachmentChecks"].toArray()){
        auto check=value.toObject();const double maximum=check["maximumDistanceMm"].toDouble(-1),minimum=check["minimumAreaMm2"].toDouble(-1);
        if(!std::isfinite(maximum)||maximum<=0||!std::isfinite(minimum)||minimum<=0)throw std::runtime_error("invalid contact limits");
        auto a=ContactShape(check,"first",shapes),b=ContactShape(check,"second",shapes);
        if(check.contains("secondTranslationMm")){const auto p=check["secondTranslationMm"].toArray();if(p.size()!=3)throw std::runtime_error("invalid contact perturbation");
            gp_Trsf t;t.SetTranslation(gp_Vec(p[0].toDouble(),p[1].toDouble(),p[2].toDouble()));b=BRepBuilderAPI_Transform(b,t,true).Shape();}
        const auto left=ContactFaces(a),right=ContactFaces(b);TopoDS_Shape region;
        if(check.contains("region")){const auto r=check["region"].toArray();if(r.size()!=6)throw std::runtime_error("invalid contact region");
            for(int i=0;i<3;++i)if(!std::isfinite(r[i].toDouble())||!std::isfinite(r[i+3].toDouble())||r[i+3].toDouble()<=r[i].toDouble())throw std::runtime_error("invalid contact box");
            region=BRepPrimAPI_MakeBox(gp_Pnt(r[0].toDouble(),r[1].toDouble(),r[2].toDouble()),gp_Pnt(r[3].toDouble(),r[4].toDouble(),r[5].toDouble())).Shape();
            a=ContactIntersection(a,region);b=ContactIntersection(b,region);}
        BRepExtrema_DistShapeShape distance(a,b);double gap=1e30,area=0;
        if(distance.IsDone()&&distance.NbSolution()>0)gap=distance.Value();
        if(gap<=maximum){
            for(const auto& f:left)for(const auto& g:right){bool close=true;
                for(int i=0;i<3;++i)if(std::min(f.b[i+3],g.b[i+3])-std::max(f.b[i],g.b[i]) < -maximum){close=false;break;}
                if(!close)continue;auto surface=ContactIntersection(f.shape,g.shape);
                if(!region.IsNull())surface=ContactIntersection(surface,region);
                GProp_GProps props;BRepGProp::SurfaceProperties(surface,props);area+=std::abs(props.Mass());}}
        check["distanceMm"]=gap;check["contactAreaMm2"]=area;check["passed"]=gap<=maximum&&area>=minimum;
        if(!check["passed"].toBool())++failures;results.append(check);
    }return results;
}

QJsonArray CheckAssembly(const QJsonObject& design,const std::map<std::string,std::string>& shapes,int& failures) {
    QJsonArray results;
    for(const auto value:design["assemblyChecks"].toArray()) {
        auto check=value.toObject();const auto first=ReadShape(shapes,check["first"].toString());
        const auto second=ReadShape(shapes,check["second"].toString());
        BRepAlgoAPI_Common common(first,second);common.Build();
        if(!common.IsDone())throw std::runtime_error("assembly intersection failed");
        const double overlap=Volume(common.Shape());check["overlapMm3"]=overlap;
        check["passed"]=!check["noOverlap"].toBool()||overlap<=1e-6;
        if(!check["passed"].toBool())++failures;results.append(check);
    }
    return results;
}

QJsonArray CheckSplit(const QJsonObject& design,const std::map<std::string,std::string>& shapes,int& failures) {
    QJsonArray results;
    for(const auto value:design["splitChecks"].toArray()) {
        auto check=value.toObject();const auto source=ReadShape(shapes,check["source"].toString());
        const auto front=ReadShape(shapes,check["front"].toString());const auto rear=ReadShape(shapes,check["rear"].toString());
        BRepAlgoAPI_Fuse joined(front,rear);joined.Build();
        if(!joined.IsDone())throw std::runtime_error("split reassembly failed");
        BRepAlgoAPI_Cut missing(source,joined.Shape()),excess(joined.Shape(),source);
        if(!missing.IsDone()||!excess.IsDone())throw std::runtime_error("split comparison failed");
        const double error=Volume(missing.Shape())+Volume(excess.Shape());
        const double tolerance=std::max(1e-6,Volume(source)*1e-8);
        check["symmetricDifferenceMm3"]=error;check["toleranceMm3"]=tolerance;
        check["passed"]=BRepCheck_Analyzer(joined.Shape()).IsValid()&&error<=tolerance;
        if(!check["passed"].toBool())++failures;results.append(check);
    }
    return results;
}

QJsonObject PointRayDiagnostic(const TopoDS_Shape& shape,const gp_Pnt& point,
    IntCurvesFace_ShapeIntersector* preparedRay=nullptr,const Bnd_Box* preparedBounds=nullptr){
    Bnd_Box bounds;if(preparedBounds)bounds=*preparedBounds;else BRepBndLib::AddOptimal(shape,bounds,false,false);
    double lo[3],hi[3];bounds.Get(lo[0],lo[1],lo[2],hi[0],hi[1],hi[2]);
    IntCurvesFace_ShapeIntersector localRay;if(!preparedRay)localRay.Load(shape,1e-7);
    auto& ray=preparedRay?*preparedRay:localRay;
    ray.Perform(gp_Lin(gp_Pnt(lo[0]-1,point.Y(),point.Z()),gp_Dir(1,0,0)),0,hi[0]-lo[0]+2);
    if(ray.IsDone())ray.SortResult();QJsonArray hits;bool usable=ray.IsDone(),inside=false;double last=-1e300;
    if(ray.IsDone())for(int i=1;i<=ray.NbPnt();++i){const double x=ray.Pnt(i).X();
        hits.append(QJsonObject{{"x",x},{"state",int(ray.State(i))},{"transition",int(ray.Transition(i))}});
        if(ray.State(i)!=TopAbs_IN||x-last<=1e-6||int(ray.Transition(i))!=(i%2?1:2))usable=false;
        if(x<point.X())inside=!inside;last=x;}
    if(hits.size()%2)usable=false;
    return QJsonObject{{"rayDone",ray.IsDone()},{"fixedXRay",hits},{"rayUsable",usable},{"rayInside",inside}};
}

QJsonObject PointBoundaryDiagnostic(const TopoDS_Shape& shape,const gp_Pnt& point){
    BRep_Builder builder;TopoDS_Compound faces;builder.MakeCompound(faces);
    for(TopExp_Explorer e(shape,TopAbs_FACE);e.More();e.Next())builder.Add(faces,e.Current());
    BRepExtrema_DistShapeShape distance(BRepBuilderAPI_MakeVertex(point).Shape(),faces);
    QJsonObject result=PointRayDiagnostic(shape,point);QJsonArray nearest;
    if(distance.IsDone()){
        result["boundaryDistanceMm"]=distance.Value();
        for(int i=1;i<=distance.NbSolution();++i){
            QJsonObject row;const auto support=distance.SupportOnShape2(i);const auto q=distance.PointOnShape2(i);
            row["point"]=QJsonArray{q.X(),q.Y(),q.Z()};row["supportType"]=int(distance.SupportTypeShape2(i));
            if(distance.SupportTypeShape2(i)==BRepExtrema_IsInFace){
                double u,v;distance.ParOnFaceS2(i,u,v);gp_Pnt p;gp_Vec du,dv;
                const auto face=TopoDS::Face(support);BRepAdaptor_Surface surface(face);surface.D1(u,v,p,du,dv);
                row["c1Surface"]=surface.UContinuity()>=GeomAbs_C1&&surface.VContinuity()>=GeomAbs_C1;
                gp_Vec normal=du.Crossed(dv);if(face.Orientation()==TopAbs_REVERSED)normal.Reverse();
                if(normal.Magnitude()>1e-12){normal.Normalize();row["outwardDotMm"]=normal.Dot(gp_Vec(q,point));}
                row["uv"]=QJsonArray{u,v};row["reversed"]=face.Orientation()==TopAbs_REVERSED;
            }nearest.append(row);
        }
    }
    result["nearest"]=nearest;
    // A smooth, unique nearest face and an independent, non-tangent BRep ray
    // must agree. Do not rescue rejected classifiers, edge/tangent ambiguity,
    // on-boundary probes, or a merely matching STL/expected answer.
    bool usable=result["rayUsable"].toBool()&&nearest.size()==1&&distance.IsDone()&&distance.Value()>2e-5;
    const bool rayInside=result["rayInside"].toBool();bool conflict=false;
    if(usable){const auto face=nearest[0].toObject();const double dot=face["outwardDotMm"].toDouble(1e300);
        if(!face["c1Surface"].toBool()||!face.contains("outwardDotMm")||std::abs(std::abs(dot)-distance.Value())>1e-6)usable=false;
        if(usable&&(dot<0)!=rayInside){conflict=true;usable=false;}
        if(usable)result["independentInside"]=rayInside;}
    result["independentUsable"]=usable;result["independentConflict"]=conflict;return result;
}

QJsonArray CheckPoints(const QJsonObject& design,const std::map<std::string,std::string>& shapes,int& failures) {
    QJsonArray results;std::map<QString,TopoDS_Shape> loaded;std::map<QString,Bnd_Box> bounds;
    std::map<QString,std::unique_ptr<IntCurvesFace_ShapeIntersector>> rays;
    std::map<QString,std::unique_ptr<BRepClass3d_SolidClassifier>> classifiers;
    for(const auto value:design["pointChecks"].toArray()) {
        auto check=value.toObject();const auto point=check["point"].toArray();
        if(point.size()!=3||!check["expectedInside"].isBool())throw std::runtime_error("invalid point check");
        const auto id=check["entity"].toString();
        if(!loaded.count(id)){
            loaded[id]=ReadShape(shapes,id);BRepBndLib::AddOptimal(loaded[id],bounds[id],false,false);
            rays[id]=std::make_unique<IntCurvesFace_ShapeIntersector>();rays[id]->Load(loaded[id],1e-7);
            classifiers[id]=std::make_unique<BRepClass3d_SolidClassifier>(loaded[id]);
        }
        const auto& shape=loaded[id];auto& classifier=*classifiers[id];
        classifier.Perform(gp_Pnt(point[0].toDouble(),point[1].toDouble(),point[2].toDouble()),1e-6);
        const bool inside=classifier.State()==TopAbs_IN;
        check["rawInside"]=inside;check["onBoundary"]=classifier.State()==TopAbs_ON;
        check["rawState"]=int(classifier.State());check["rejected"]=classifier.Rejected();
        const gp_Pnt position(point[0].toDouble(),point[1].toDouble(),point[2].toDouble());
        auto diagnostic=PointRayDiagnostic(shape,position,rays[id].get(),&bounds[id]);
        const bool disagreement=diagnostic["rayUsable"].toBool()&&diagnostic["rayInside"].toBool()!=inside;
        if(disagreement)diagnostic=PointBoundaryDiagnostic(shape,position);
        const bool independent=diagnostic["independentUsable"].toBool();
        const bool verifiedInside=independent?diagnostic["independentInside"].toBool():inside;
        check["inside"]=verifiedInside;check["independentUsable"]=independent;
        check["classificationDisagreement"]=independent&&verifiedInside!=inside;
        check["fixedRayUsable"]=diagnostic["rayUsable"].toBool();
        check["passed"]=!classifier.Rejected()&&!diagnostic["independentConflict"].toBool()&&(!disagreement||independent)&&classifier.State()!=TopAbs_UNKNOWN&&classifier.State()!=TopAbs_ON&&verifiedInside==check["expectedInside"].toBool();
        if(!check["passed"].toBool()||disagreement)check["boundaryDiagnostic"]=diagnostic;
        if(!check["passed"].toBool())++failures;results.append(check);
    }
    return results;
}

int main(int argc,char** argv) {
    QCoreApplication app(argc,argv);if(argc!=4&&argc!=5)return 2;
    const bool checkOnly=argc==5&&QString::fromLocal8Bit(argv[4])=="--check-only";
    const bool previewOnly=argc==5&&QString::fromLocal8Bit(argv[4])=="--preview-only";
    if(argc==5&&!checkOnly&&!previewOnly)return 2;
    try {
        QFile file(QString::fromLocal8Bit(argv[1]));if(!file.open(QIODevice::ReadOnly))return 3;
        QDataStream data(&file);data.setVersion(QDataStream::Qt_6_0);data.setFloatingPointPrecision(QDataStream::DoublePrecision);
        if(Text(data)!="kachakacha-prepared-document")throw std::runtime_error("bad header");
        qint64 version;data>>version;if(version!=2)throw std::runtime_error("bad version");
        auto token=Text(data);auto archive=Text(data);
        quint64 count;data>>count;if(count>1000000)throw std::runtime_error("bad shape count");
        std::map<std::string,std::string> shapes;
        for(quint64 i=0;i<count;++i){auto id=Text(data);shapes.emplace(id,Text(data));}
        const auto design=Json(QString::fromLocal8Bit(argv[2]));const QDir out(QString::fromLocal8Bit(argv[3]));QDir().mkpath(out.path());
        const double chord=design["stlChordMm"].toDouble(.025);
        if(!std::isfinite(chord)||chord<=0||chord>.025)throw std::runtime_error("invalid mesh precision");
        if(design["entities"].toArray().isEmpty()||design["groups"].toArray().isEmpty())
            throw std::runtime_error("empty or invalid design manifest");
        std::map<QString,QJsonObject> groups;
        for(const auto value:design["groups"].toArray()){auto g=value.toObject();groups[g["id"].toString()]=g;}
        QJsonArray results;int failures=0,index=0;
        const auto assembly=CheckAssembly(design,shapes,failures);
        const auto split=CheckSplit(design,shapes,failures);
        const auto points=CheckPoints(design,shapes,failures);
        const auto contacts=CheckContacts(design,shapes,failures);
        Interface_Static::SetCVal("write.step.unit","MM");
        for(const auto value:design["entities"].toArray()) {
            const auto entity=value.toObject();if(entity["kind"]!="part"||entity["visibility"]!="visible")continue;
            const auto id=entity["id"].toString();QJsonObject row{{"id",id},{"name",entity["displayName"]}};
            const double partChord=design["stlChordByEntity"].toObject()[id].toDouble(chord);
            if(!std::isfinite(partChord)||partChord<=0||partChord>.025)throw std::runtime_error("invalid part mesh precision");
            row["chordMm"]=partChord;
            const auto found=shapes.find(id.toStdString());
            if(found==shapes.end()){row["error"]="missing CAD-evaluated shape";results.append(row);++failures;continue;}
            std::istringstream stream(found->second);BRep_Builder builder;TopoDS_Shape shape;BRepTools::Read(shape,stream,builder);
            int solids=0;for(TopExp_Explorer ex(shape,TopAbs_SOLID);ex.More();ex.Next())++solids;
            GProp_GProps prop;const double sourceError=BRepGProp::VolumeProperties(shape,prop,1e-10);
            bool valid=!shape.IsNull()&&BRepCheck_Analyzer(shape).IsValid()&&solids==1&&prop.Mass()>1e-8;
            row["valid"]=valid;row["solids"]=solids;row["volumeMm3"]=prop.Mass();
            row["sourceIntegrationError"]=sourceError;
            Bnd_Box box;BRepBndLib::AddOptimal(shape,box,false,false);double a,b,c,d,e,f;box.Get(a,b,c,d,e,f);
            row["bounds"]=QJsonArray{a,b,c,d,e,f};
            const bool envelope=a>=-5&&b>=-21&&c>=-1&&d<=250&&e<=21&&f<=52;
            row["withinModelEnvelope"]=envelope;valid=valid&&envelope;row["valid"]=valid;
            QString group=entity["groupId"].toString();QStringList names;
            for(int depth=0;groups.contains(group)&&depth<50;++depth){auto g=groups[group];names.prepend(g["displayName"].toString());group=g["parentGroupId"].toString();}
            row["groupPath"]=names.join('/');row["manufacturing"]=entity["partProperties"].toObject()["manufacturing"];
            const auto stem=QString("part-%1-%2").arg(++index,3,10,QChar('0')).arg(id.left(8));
            if(valid&&!checkOnly) {
                BRepMesh_IncrementalMesh mesh(shape,partChord,false,.12,false);
                const auto stl=out.filePath(stem+".stl");StlAPI_Writer writer;writer.ASCIIMode()=false;
                const bool stlOk=writer.Write(shape,stl.toUtf8().constData());
                row["stl"]=stem+".stl";
                if(previewOnly){
                    // Intermediate visual inspection only. A final deliverable
                    // must still use the unchanged full STEP round-trip path.
                    row["exported"]=stlOk;row["stepRoundTrip"]=false;
                    if(!stlOk)++failures;results.append(row);continue;
                }
                STEPControl_Writer step;const auto transferred=step.Transfer(shape,STEPControl_AsIs);
                const auto path=out.filePath(stem+".step");const auto written=transferred==IFSelect_RetDone?step.Write(path.toUtf8().constData()):IFSelect_RetError;
                row["stl"]=stem+".stl";row["step"]=stem+".step";row["exported"]=stlOk&&written==IFSelect_RetDone;
                STEPControl_Reader reader;
                bool roundtrip=written==IFSelect_RetDone&&reader.ReadFile(path.toUtf8().constData())==IFSelect_RetDone;
                if(roundtrip) {
                    reader.TransferRoots();const auto restored=reader.OneShape();GProp_GProps restoredProperties;
                    row["stepIntegrationError"]=BRepGProp::VolumeProperties(restored,restoredProperties,1e-10);
                    const double delta=std::abs(restoredProperties.Mass()-prop.Mass());row["stepVolumeDeltaMm3"]=delta;
                    roundtrip=BRepCheck_Analyzer(restored).IsValid()&&delta<=std::max(1e-5,std::abs(prop.Mass())*1e-7);
                }
                row["stepRoundTrip"]=roundtrip;if(!roundtrip)++failures;
                if(!row["exported"].toBool())++failures;
            }else if(!valid)++failures;
            results.append(row);
        }
        if(index==0)throw std::runtime_error("zero visible parts");
        QJsonObject report{{"preparedToken",QString::fromStdString(token)},{"cadShapes",int(count)},{"visibleParts",index},
            {"failures",failures},{"checkOnly",checkOnly},{"previewOnly",previewOnly},{"chordMm",chord},{"assemblyChecks",assembly},{"splitChecks",split},{"pointChecks",points},{"attachmentChecks",contacts},{"parts",results}};
        QFile result(out.filePath("print-parts.json"));if(!result.open(QIODevice::WriteOnly))return 4;result.write(QJsonDocument(report).toJson());
        std::cout<<"visible="<<index<<" failures="<<failures<<std::endl;return failures?1:0;
    }catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 5;}
}

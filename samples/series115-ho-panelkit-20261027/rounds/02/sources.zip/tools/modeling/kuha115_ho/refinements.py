"""Successive photo-reviewed design candidates; local radii are estimates."""
import math

REVISION='2026-10-27-ten-round-print-kit'


def enabled(model,stage=1):return getattr(model,'refinement_pass',0)>=stage


def longitudinal_radius(model):return 6.3 if enabled(model) else 9.0


def transverse_radius(model):return 48.0 if enabled(model,2) else 40.0


def plan_front_x(y,inset=0):
    y=abs(y);half=5.3;r=3.8-inset;side=18.125-inset;angle=math.radians(8)
    cy=side-r;yt=cy+r*math.sin(angle)
    cx=inset+r*math.cos(angle)+math.tan(angle)*(yt-half)
    if y<=half:return inset
    if y<=yt:return inset+math.tan(angle)*(y-half)
    return cx-math.sqrt(max(0,r*r-(y-cy)**2))


def roof_front_x(spec,y,z,inset=0):
    radius=spec.radius-inset;top=spec.height(y,inset);dz=z-(top-radius)
    if z>=top:return None
    circular=inset if dz<=0 else spec.radius-math.sqrt(max(0,radius*radius-dz*dz))
    return max(plan_front_x(y,inset),circular)


def forehead_checks(model,spec,roof):
    # These are classified against the evaluated native BRep. The separate STL
    # section audit compares the actual roof/body boundaries across revisions.
    for y in [-16.5,-14,-10,-5.3,0,5.3,10,14,16.5]:
        for z in [39.04,39.5,40.,40.5]:
            outer=roof_front_x(spec,y,z)
            if outer is None:continue
            inner=roof_front_x(spec,y,z,1.)
            middle=(outer+inner)/2 if inner is not None and inner>outer+.02 else outer+.12
            for x,inside in [(outer-.08,False),(middle,True)]:
                model.points.append(dict(entity=roof,label='改訂額・平面クリップ後の外側と肉厚中心',point=[x,y,z],expectedInside=inside))
            if inner is not None and inner>outer+.02:
                model.points.append(dict(entity=roof,label='改訂額・平面クリップ後の内側空間',point=[inner+.08,y,z],expectedInside=False))
        # The old long radius leaves a visible ledge at the body/roof joint.
        model.points.append(dict(entity=roof,label='車体前面の直上に連続する屋根下縁',
            point=[plan_front_x(y)+.08,y,39.04],expectedInside=True))
        if enabled(model,2):
            sine=.9;cosine=math.sqrt(1-sine*sine)
            h=spec.height(y);derivative=(spec.height(y+.0001)-spec.height(y-.0001))/.0002
            normal=(-cosine,-sine*derivative,sine)
            length=math.sqrt(sum(v*v for v in normal));normal=tuple(v/length for v in normal)
            anchor=(spec.radius*(1-cosine),y,h-spec.radius+spec.radius*sine)
            for distance,inside in [(.12,False),(-.85,True)]:
                model.points.append(dict(entity=roof,label='改訂額・法線方向の外側と残存肉厚',
                    point=[p+distance*n for p,n in zip(anchor,normal)],expectedInside=inside))


def manifest(model):
    stage=model.refinement_pass
    return dict(revision=REVISION,stage=stage,complete=False,
        longitudinalRadiusMm=longitudinal_radius(model),transverseRadiusMm=transverse_radius(model),
        dimensionStatus='Local radii are photo-reviewed model design estimates, not measured prototype dimensions.',
        changes=['Forehead/body boundary follows the folded plan without the old exterior step']+
            (['Shallower transverse crown with a larger tangent shoulder radius'] if stage>=2 else []))

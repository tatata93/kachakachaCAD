"""Positive and deliberately wrong controls for the manufacturing checker."""
from pathlib import Path
import argparse,copy,datetime,hashlib,json,os,subprocess,sys
from build import Train


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--exe',type=Path,required=True);ap.add_argument('--exporter',type=Path,required=True);ap.add_argument('--work',type=Path,required=True)
    a=ap.parse_args();work=a.work.resolve();work.mkdir(parents=True,exist_ok=False);m=Train();g=m.group('Checker contract')
    whole=m.box('Whole',0,0,20,3,2,2,g);obstacle=m.box('Obstacle',4,0,20,1,2,2,g)
    pieces=[m.box('Piece '+str(i),i,0,20,1,2,2,g) for i in range(3)];m.entities[whole]['visibility']='hidden'
    model=work/'contract.kcd2';m.save(model)
    validator=Path(__file__).resolve().parents[1]/'series115_print/validate_model.py'
    subprocess.run([sys.executable,str(validator),str(model),str(a.exe.resolve()),'--work',str(work/'native')],check=True)
    design=dict(entities=m.d['entities'],groups=m.d['groups'],stlChordMm=.01,pointChecks=[],assemblyChecks=[],attachmentChecks=[],
        splitChecks=[dict(source=whole,parts=pieces,label='Three exact pieces')],
        insertionChecks=[dict(moving=[whole],fixed=[obstacle],vectorMm=[-5,0,0],label='Continuous separation')])
    cases=[('positive',design,0)]
    bad=copy.deepcopy(design);bad['splitChecks'][0]['parts']=[pieces[0],pieces[2]];cases.append(('missing-piece',bad,1))
    bad=copy.deepcopy(design);bad['insertionChecks'][0]['vectorMm']=[2,0,0];cases.append(('path-obstruction',bad,1))
    bad=copy.deepcopy(design);bad['splitChecks'][0]['parts']=[pieces[0],pieces[0]];cases.append(('duplicate-piece',bad,5))
    bad=copy.deepcopy(design);bad['insertionChecks'][0]['vectorMm']=[0,0,0];cases.append(('empty-path',bad,5))
    env=os.environ.copy();env['PATH']=str(a.exe.resolve().parent)+os.pathsep+env.get('PATH','');rows=[]
    for name,d,expected in cases:
        path=work/(name+'.json');path.write_text(json.dumps(d),encoding='utf-8');out=work/name
        result=subprocess.run([str(a.exporter.resolve()),str(work/'native/prepared.bin'),str(path),str(out),'--check-only'],env=env,capture_output=True,text=True,timeout=120)
        (work/(name+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
        assert result.returncode==expected,(name,result.returncode,result.stdout,result.stderr)
        report=json.loads((out/'print-parts.json').read_text(encoding='utf-8')) if (out/'print-parts.json').exists() else None
        if name=='positive':assert report['splitChecks'][0]['passed'] and report['insertionChecks'][0]['passed'] and not report['failures']
        elif name=='missing-piece':assert not report['splitChecks'][0]['passed'] and report['splitChecks'][0]['symmetricDifferenceMm3']>3.99
        elif name=='path-obstruction':assert not report['insertionChecks'][0]['passed'] and report['insertionChecks'][0]['maximumOverlapMm3']>3.99
        rows.append(dict(name=name,expectedExit=expected,actualExit=result.returncode,passed=True))
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    (work/'result.json').write_text(json.dumps(dict(passed=True,cases=rows,exeSha256=sha(a.exe),exporterSha256=sha(a.exporter),
        modelSha256=sha(model),timeUtc=datetime.datetime.now(datetime.timezone.utc).isoformat()),indent=2),encoding='utf-8')
    print('PASS manufacturing checker controls:',len(rows))


if __name__=='__main__':main()
